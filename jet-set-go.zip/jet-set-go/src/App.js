import React from 'react';
import './App.css';
import { Routes, Route } from 'react-router-dom'; // Use Routes and Route
import NavbarMain from './components/Navbar';
import Home from './pages/Home';
import Tour from './pages/Tour';


function App() {
  return (
    <div className="App">
      <NavbarMain />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="tour" element={<Tour />} />
        
      </Routes>
    </div>
  );
}

export default App;

