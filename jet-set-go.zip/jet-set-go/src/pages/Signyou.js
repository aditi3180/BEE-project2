
import React, { Component } from "react";
import Login from './components/Login';



class Signyou extends Component {
  render() {
    return(
    <div id="Signyou">
        <Login />
        </div>
      
    )
  }
}

export default Signyou;