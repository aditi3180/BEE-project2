import React, { useState } from 'react';
import './Login.css';

function Login() {
  const [loginVisible, setLoginVisible] = useState(true);
  const [signupVisible, setSignupVisible] = useState(false);
  const [email,setEmail]=useState('');        
  const [gmail,setGmail]=useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [gmailList, setGmailList] = useState([]);    //for authentication purposes


  const toggleLogin = () => {
    setLoginVisible(true);
    setSignupVisible(false);
    setError('')
  };

  const toggleSignup = () => {
    setLoginVisible(false);
    setSignupVisible(true);
    setError('')
  };

  const handleEmailChange = (e) => {
    setEmail(e.target.value);
  };

  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
  };

  const handleGmailChange = (e) => {
    setGmail(e.target.value);
  };
  


  const handleLogin = () => {
    if (email && password) {
      const user = gmailList.find((user) => user.email === email && user.password === password);
      if (user) {
        alert('Successfully logged in');
      } else {
        alert('Invalid email or password');
      }
    } else {
      alert('Email and password are required');
    }
  };

  

  const handleSignup = () => {
    if(gmail && gmail.includes('@gmail.com') && password){
      const newUser = { email: gmail, password };

       // Add the new user to the Gmail list
       setGmailList([...gmailList, newUser]);

       setGmail('');
       setPassword('');

    alert('Successfully signed in');
    }
    else{
      alert('Email and password are required');
    }
  };
  
  
  return (
    <div className='hero'>
      <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
  <div class="cube"></div>
    <div className="rowww">
  

      <div className={`form-container ${loginVisible ? '' : 'hidden'}`}>
      <h1>Login</h1>
<form>
  <input type="email" placeholder="Email" value={email} onChange={handleEmailChange} required style={{ height: '50px', width: '200px' }} /><br /><br />
  <input type="password" placeholder="Password" value={password} onChange={handlePasswordChange} required style={{ height: '50px', width: '200px' }} /><br /><br /><br />
 
  <br /><br />
  <button onClick={handleLogin} style={{height: '50px',width:'130px',backgroundColor:'cyan',borderRadius: '30px',color:'black'}}>Login</button>
  <h4>Or</h4>
</form>

            <h4>Don't have an account? <a href="#" onClick={toggleSignup}>Sign Up</a></h4>
          </div>

          <div className={`form-container ${signupVisible ? '' : 'hidden'}`}>
            <h1>Sign Up</h1>
            <form>
               <input type="email" placeholder="Email" value={gmail} onChange={handleGmailChange} required style={{ height: '50px', width: '200px' }} /><br /><br />
                <input type="password" placeholder="Password" value={password} onChange={handlePasswordChange} required style={{ height: '50px', width: '200px' }} /><br /><br /><br />
                 <br /><br />
              <button onClick={handleSignup}  style={{height: '50px',width:'130px',backgroundColor:'#FF4B91',borderRadius: '30px',color:'black'} }>Sign Up</button>
              <br />
              <h4>Or</h4>
              <h4>Already have an account? <a href="#" onClick={toggleLogin}>Login</a></h4>
            </form>
            
          </div>
        </div>
        {error && <p>{error}</p>}
    
     </div>
  );
}




export default Login;