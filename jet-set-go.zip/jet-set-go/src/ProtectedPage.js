import { UserButton } from "@clerk/clerk-react"

const  ProtectedPage=()=>{
    return(
        <UserButton/>
    )
}
export default ProtectedPage;