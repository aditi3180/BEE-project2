import React, { Component } from "react";
import { Container, Row, CardColumns, Badge } from "reactstrap";
import TourCard from "./TourCard";
import "../App.css";
import imgCard1 from "../img/img-card (1).jpg";
import imgCard2 from "../img/img-card (2).jpg";
import imgCard3 from "../img/img-card (3).jpg";
import imgCard4 from "../img/img-card (4).jpg";
import imgCard5 from "../img/img-card (5).jpg";
import imgCard6 from "../img/img-card (6).jpg";
import imgCard7 from "../img/img-card (7).jpg";
import imgCard8 from "../img/img-card (8).jpg";
import imgCard9 from "../img/img-card (9).jpg";
import imgBarobaybay from "../img/barobaybay.jpg";
const tours = [
  {
    id: 1,
    category: ["3Star", "7Star"],
    img: imgCard1,
    alt: "blah blah",
    title: "RADISSON RED",
    subtitle: "CHANDIGARH"
  },
  {
    id: 2,
    category: ["1Star", "2Star"],
    img: imgCard2,
    alt: "blah blah",
    title: "GOWALIAA",
    subtitle: "GOA"
  },
  {
    id: 3,
    category: ["3Star", "7Star"],
    img: imgCard3,
    alt: "blah blah",
    title: "The Farm",
    subtitle: "DARJELING"
  },
  {
    id: 4,
    category: ["4Star", "2Star"],
    img: imgCard4,
    alt: "blah blah",
    title: "ROCK & CLIMB",
    subtitle: "MANALI"
  },
  {
    id: 5,
    category: ["3Star", "7Star", "1Star"],
    img: imgCard5,
    alt: "blah blah",
    title: "PORT RESORT",
    subtitle: "ANDAMAN AND NICOBAR ISLAND"
  },
  {
    id: 6,
    category: ["4Star", "2Star"],
    img: imgCard6,
    alt: "blah blah",
    title: "",
    subtitle: ""
  },
  {
    id: 7,
    category: ["1Star", "4Star"],
    img: imgCard7,
    alt: "blah blah",
    title: "KANAD BEACH",
    subtitle: "KERALA"
  },
  {
    id: 8,
    category: ["7Star", "1Star", "3Star"],
    img: imgCard8,
    alt: "blah blah",
    title: "LOVE SPOT",
    subtitle: "CHENNAI"
  },
  {
    id: 9,
    category: ["1Star", "3Star"],
    img: imgCard9,
    alt: "blah blah",
    title: "CHILL AND MAAL",
    subtitle: "MALDIVES"
  },
  {
    id: 10,
    category: ["5Star", "1Star"],
    img: imgBarobaybay,
    alt: "5Star in the lake",
    title: " Camp Site",
    subtitle: "RISHIKESH"
  }
];

const itemCategories = [
  "all",
  "1Star",
  "2Star",
  "3Star",
  "4Star",
  "5Star",
  "7Star"
];

class Package extends Component {
  state = {
    cards: [],
    category: "all"
  };

  componentDidMount() {
    this.setState({ cards: tours });
  }

  render() {
    const { cards, category } = this.state;
    return (
      <div className="subComponent-lg" id="packageBody">
        <Container>
          <header className="headerTitle text-center">
            <h1>Tour Packages</h1>
            <p>A Great Collection of Our Tour Packages</p>
          </header>
          <section className="packageBody text-center">
            {itemCategories.map((badge, index) => (
              <Badge
                key={index}
                href=""
                color={badge === category ? "dark" : "light"}
                onClick={() => this.setState({ category: badge })}
              >
                {badge}
              </Badge>
            ))}

            <Row className="text-left">
              <CardColumns>
                {category !== "all"
                  ? cards.map(tourcard => {
                    return tourcard.category.map(catItem => {
                      return catItem === category ? (
                        <TourCard key={tourcard.id} tourcard={tourcard} />
                      ) : null;
                    });
                  })
                  : cards.map(tourcard => (
                    <TourCard key={tourcard.id} tourcard={tourcard} />
                  ))}
              </CardColumns>
            </Row>
          </section>
        </Container>
      </div>
    );
  }
}

export default Package;

